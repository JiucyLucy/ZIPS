# VulnerableService
Powershell script to create a vulnerable service, that can be easily used for privilege escalation 

Taken from Joe Vest's (threatexpress) github.

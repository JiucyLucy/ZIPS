## Web Applications penetration testing related PAYLOADS that are actually useful

- **`Server-Side-Template-Injections.txt`** - Various Server-Side Template Injection static payloads, targeting couple of various templating implementations (also some of the Client-Side ones like in AngularJS). The evaluated expression to look/grep for is: **1868686868** or **aaaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbbbbbb**. Use it with Burp Intruder's Grep functionality, or simply look out for that pattern while hanging around the application. ([gist](https://gist.github.com/mgeeky/2b660ab8d3946eec519731ed9ec5d25b))


## File-Formats Penetration Testing related scripts, tools and Cheatsheets


- **`zipcrack.rb`** - Simple multi-threaded ZIP cracker. ([gist](https://gist.github.com/mgeeky/f89262744fa37e9ec2351dccdc81b44c))

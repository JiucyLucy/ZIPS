using System;

class Program 
{
	static void Main() 
	{
		Console.WriteLine("Hello World!");
		Console.WriteLine("Press any key to exit.");
		Console.ReadKey();
	}
}

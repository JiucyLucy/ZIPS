Was initially written in order to  automate Windows security hardening manipulations for Microsoft infrastructure during LS19.

Default mode: Audit (no config changes implemented).

In order to implement actual hardening - uncomment `-configure` option at last line of the script:
```
Main #-configure
```

Run as Administrator to get full power.
